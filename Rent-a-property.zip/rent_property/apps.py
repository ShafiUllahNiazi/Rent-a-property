from django.apps import AppConfig


class RentPropertyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rent_property'
