from setuptools import setup

__version__ = "2.1.0"

setup(
   name="my-package",
   version=__version__,
   # And so on...
)

